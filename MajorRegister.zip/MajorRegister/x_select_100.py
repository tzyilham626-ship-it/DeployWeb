import json

src_file = "accounts_ind.json"
dest_file = "accounts.json"

with open(src_file, "r", encoding="utf-8") as f:
    data = json.load(f)

if not isinstance(data, list):
    raise ValueError("The JSON file must contain an array of objects at the top level.")

first_100 = data[:100]

with open(dest_file, "w", encoding="utf-8") as f:
    json.dump(first_100, f, indent=4, ensure_ascii=False)

remaining = data[100:]

with open(src_file, "w", encoding="utf-8") as f:
    json.dump(remaining, f, indent=4, ensure_ascii=False)

print(f"Moved {len(first_100)} accounts to {dest_file} and updated {src_file}")