import json

ACCOUNTS_FILE = "accounts.json"

def count_accounts():
    try:
        with open(ACCOUNTS_FILE, "r") as f:
            accounts = json.load(f)
            print(f"Total accounts: {len(accounts)}")
    except FileNotFoundError:
        print(f"Error: {ACCOUNTS_FILE} not found.")
    except json.JSONDecodeError:
        print("Error: Invalid JSON format in accounts.json")

if __name__ == "__main__":
    count_accounts()