import json

input_file = "accounts.json"
output_file = "x_accounts.txt"

with open(input_file, "r", encoding="utf-8") as f:
    accounts = json.load(f)

lines = []
for acc in accounts:
    line = {
        "guest_account_info": {
            "com.garena.msdk.guest_password": acc["password"],
            "com.garena.msdk.guest_uid": str(acc["uid"])
        }
    }
    lines.append(json.dumps(line, ensure_ascii=False))

with open(output_file, "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

print(f"Written {len(lines)} accounts to {output_file}")
