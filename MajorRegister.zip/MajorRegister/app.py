from flask import Flask, jsonify
import random 
import asyncio
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import ssl
import aiohttp
import string
import hmac
import base64
import binascii
import hashlib
import MajorLoginReq_pb2
import MajorLoginRes_pb2
import MajorRegisterReq_pb2
import MajorRegisterRes_pb2
import ChooseNickname_pb2
import json
import os

async def ReleaseVersion():
    url = "https://bdversion.ggbluefox.com/live/ver.php?version=1.115.13&lang=en&device=android&channel=3rd_party&appstore=thirdparty&region=IND&release_version=OB26&whitelist_version=1.3.0&whitelist_sp_version=1.0.0&device_name=samsung%20SM-G977N&device_CPU=x86-64%20SSE3%20SSE4.1%20SSE4.2%20AVX&device_GPU=Adreno%20%28TM%29%20640&device_mem=3941"

    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            text = await response.text()
            try:
                data = json.loads(text)
                latest_version = data.get("latest_release_version")
                return latest_version
            except json.JSONDecodeError:
                return None

headers = {
    'User-Agent': "Dalvik/2.1.0 (Linux; U; Android 11; ASUS_Z01QD Build/PI)",
    'Connection': "Keep-Alive",
    'Accept-Encoding': "gzip",
    'Content-Type': "application/x-protobuf",
    'Expect': "100-continue",
    'X-Unity-Version': "2018.4.11f1",
    'X-GA': "v1 1",
    'ReleaseVersion': asyncio.run(ReleaseVersion())
}

key = b'Yg&tc%DEuh6%Zc^8'
iv = b'6oyZDr22E3ychjM%'

hmac_key = b'2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3'

async def encrypt_aes(data):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return cipher.encrypt(pad(data, AES.block_size))

async def MajorLogin_Decode(MajorLoginResponse):
    proto = MajorLoginRes_pb2.MajorLoginRes()
    proto.ParseFromString(MajorLoginResponse)
    return proto

async def generate_platform_register_info(open_id):
    encoded_open_id = open_id.encode("latin1")
    xor_key = [
        0x30, 0x30, 0x30, 0x32, 0x30, 0x31, 0x37, 0x30,
        0x30, 0x30, 0x30, 0x30, 0x32, 0x30, 0x31, 0x37,
        0x30, 0x30, 0x30, 0x30, 0x30, 0x32, 0x30, 0x31,
        0x37, 0x30, 0x30, 0x30, 0x30, 0x30, 0x32, 0x30
    ]
    if len(xor_key) < len(encoded_open_id):
        times = (len(encoded_open_id) + len(xor_key) - 1) // len(xor_key)
        xor_key = (bytes(xor_key) * times)[:len(encoded_open_id)]
    return bytes([d ^ m for d, m in zip(encoded_open_id, xor_key)])

async def generate_password(random_length=64):
    characters = string.ascii_letters + string.digits
    password = ''.join(random.choice(characters) for _ in range(random_length)).upper()
    return password

async def encode_region_payload(region):
    proto = MajorRegisterReq_pb2.MajorRegisterReq()
    proto.nickname = region
    payload_bytes = proto.SerializeToString()
    encrypted_payload = await encrypt_aes(payload_bytes)
    return encrypted_payload

async def encode_payload(nickname, access_token, open_id, platform_register_info):
    proto = MajorRegisterReq_pb2.MajorRegisterReq()
    proto.nickname = nickname
    proto.access_token = access_token
    proto.open_id = open_id
    proto.avatar_id = 102000007
    proto.platform_type = 4
    proto.platformSdkId = 1
    proto.newbieChoice = 1
    proto.platform_register_info = platform_register_info
    proto.language = "ar"
    proto.game_client = 1
    payload_bytes = proto.SerializeToString()
    encrypted_payload = await encrypt_aes(payload_bytes)
    return encrypted_payload

async def MajorLoginProto_Encode(open_id, access_token):
    major_login = MajorLoginReq_pb2.MajorLogin()
    major_login.event_time = "2025-06-04 19:48:07"
    major_login.game_name = "free fire"
    major_login.platform_id = 1
    major_login.client_version = "1.114.13"
    major_login.system_software = "Android OS 9 / API-28 (PQ3B.190801.10101846/G9650ZHU2ARC6)"
    major_login.system_hardware = "Handheld"
    major_login.telecom_operator = "Verizon"
    major_login.network_type = "WIFI"
    major_login.screen_width = 1920
    major_login.screen_height = 1080
    major_login.screen_dpi = "280"
    major_login.processor_details = "ARM64 FP ASIMD AES VMH | 2865 | 4"
    major_login.memory = 3003
    major_login.gpu_renderer = "Adreno (TM) 640"
    major_login.gpu_version = "OpenGL ES 3.1 v1.46"
    major_login.unique_device_id = "Google|34a7dcdf-a7d5-4cb6-8d7e-3b0e448a0c57"
    major_login.client_ip = "176.29.80.42"
    major_login.language = "ar"
    major_login.open_id = open_id
    major_login.open_id_type = "4"
    major_login.device_type = "Handheld"
    memory_available = major_login.memory_available
    memory_available.version = 55
    memory_available.hidden_value = 81
    major_login.access_token = access_token
    major_login.platform_sdk_id = 1
    major_login.network_operator_a = "Verizon"
    major_login.network_type_a = "WIFI"
    major_login.client_using_version = "7428b253defc164018c604a1ebbfebdf"
    major_login.external_storage_total = 36235
    major_login.external_storage_available = 31335
    major_login.internal_storage_total = 2519
    major_login.internal_storage_available = 703
    major_login.game_disk_storage_available = 25010
    major_login.game_disk_storage_total = 26628
    major_login.external_sdcard_avail_storage = 32992
    major_login.external_sdcard_total_storage = 36235
    major_login.login_by = 3
    major_login.library_path = "/data/app/com.dts.freefireth-YPKM8jHEwAJlhpmhDhv5MQ==/lib/arm64"
    major_login.reg_avatar = 1
    major_login.library_token = "5b892aaabd688e571f688053118a162b|/data/app/com.dts.freefireth-YPKM8jHEwAJlhpmhDhv5MQ==/base.apk"
    major_login.channel_type = 3
    major_login.cpu_type = 2
    major_login.cpu_architecture = "64"
    major_login.client_version_code = "2019117863"
    major_login.graphics_api = "OpenGLES2"
    major_login.supported_astc_bitset = 16383
    major_login.login_open_id_type = 4
    major_login.analytics_detail = b"FwQVTgUPX1UaUllDDwcWCRBpWAUOUgsvA1snWlBaO1kFYg=="
    major_login.loading_time = 13564
    major_login.release_channel = "android"
    major_login.extra_info = "KqsHTymw5/5GB23YGniUYN2/q47GATrq7eFeRatf0NkwLKEMQ0PK5BKEk72dPflAxUlEBir6Vtey83XqF593qsl8hwY="
    major_login.android_engine_init_flag = 110009
    major_login.if_push = 1
    major_login.is_vpn = 1
    major_login.origin_platform_type = "4"
    major_login.primary_platform_type = "4"
    payload_bytes = major_login.SerializeToString()
    encrypted_payload = await encrypt_aes(payload_bytes)
    return encrypted_payload

async def MajorLogin(open_id, access_token, retries=1, delay=1):
    try:
        payload = await MajorLoginProto_Encode(open_id, access_token)
        url = "https://loginbp.common.ggbluefox.com/MajorLogin"

        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE

        for attempt in range(1, retries + 1):
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(url, data=payload, headers=headers, ssl=ssl_context) as response:
                        if response.status == 200:
                            response_body = await response.read()
                            decoded_response = await MajorLogin_Decode(response_body)
                            return decoded_response.account_uid, decoded_response.token
                 
                print(await response.read())
                await asyncio.sleep(delay)

            except Exception as e:
                print(f"MajorLogin error on attempt {attempt}: {e}")
                await asyncio.sleep(delay)

        return None, None

    except Exception as e:
        print(f"MajorLogin setup error: {e}")
        return None, None
        
async def generate_guest_uid(password, retries=3, delay=1):
    body = f"password={password}&client_type=2&source=2&app_id=100067"
    signature = hmac.new(hmac_key, body.encode("utf-8"), hashlib.sha256).hexdigest()
    url = "https://100067.connect.garena.com/oauth/guest/register"
    headers = {
        "User-Agent": "GarenaMSDK/4.0.19PB(ASUS_Z01QD; Android 12;en;US);",
        "Authorization": "Signature " + signature,
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept-Encoding": "gzip",
        "Connection": "Keep-Alive",
    }

    for attempt in range(1, retries + 1):
        async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers, data=body) as response:
                if response.status == 200:
                    response_body = await response.json()
                    uid = response_body.get("uid")
                    if uid:
                        return uid
        await asyncio.sleep(delay)

    return None

async def token_grant(guest_uid, password, retries=3, delay=1):
    url = "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant"
    payload = {
        "uid": guest_uid,
        "password": password,
        "response_type": "token",
        "client_type": "2",
        "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
        "client_id": "100067",
    }
    headers = {
        "user-agent": "GarenaMSDK/4.0.19P7(ASUS_AI2205_A ;Android 9;en;US;)",
        "content-type": "application/x-www-form-urlencoded",
        "accept-encoding": "gzip",
    }

    for attempt in range(1, retries + 1):
        async with aiohttp.ClientSession() as session:
            async with session.post(url, data=payload, headers=headers) as response:
                if response.status == 200:
                    response_body = await response.json()
                    access_token = response_body.get("access_token")
                    open_id = response_body.get("open_id")
                    if access_token and open_id:
                        platform_register_info = await generate_platform_register_info(open_id)
                        return access_token, open_id, platform_register_info

        print(f"token_grant attempt {attempt} failed.")
        await asyncio.sleep(delay)

    return None, None, None

async def major_register_req(nickname, access_token, open_id, platform_register_info, retries=3, delay=1):
    payload = await encode_payload(nickname, access_token, open_id, platform_register_info)
    url = "https://loginbp.ggblueshark.com/MajorRegister"

    for attempt in range(1, retries + 1):
        async with aiohttp.ClientSession() as session:
            async with session.post(url, data=payload, headers=headers) as response:
                if response.status == 200:
                    response_body = await response.read()
                    if len(response_body) < 15:
                        return "Invalid Nickname"
                    return "ok"

        await asyncio.sleep(delay)

    return None

async def choose_region(token, region, retries=3, delay=1):
    payload = await encode_region_payload(region)
    url = "https://loginbp.ggblueshark.com/ChooseRegion"

    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE

    headers['Authorization'] = f"Bearer {token}"

    for attempt in range(1, retries + 1):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, data=payload, headers=headers, ssl=ssl_context) as response:
                    if response.status == 200:
                        return "ok"

            print(f"choose_region attempt {attempt} failed.")
            await asyncio.sleep(delay)

        except Exception as e:
            print(f"choose_region error on attempt {attempt}: {e}")
            await asyncio.sleep(delay)

    return None

async def create_account(nickname, region):
    password = await generate_password()
    guest_uid = await generate_guest_uid(password)
    if not guest_uid:
        return "uid generation issue"
    access_token, open_id, platform_register_info = await token_grant(guest_uid, password)
    if not access_token or not open_id or not platform_register_info:
        return "token grant failed"
    major_register = await major_register_req(nickname, access_token, open_id, platform_register_info)
    if not major_register:
        return "Rate Limit in MajorRegister."
    if major_register == "Invalid Nickname":
    	return "PutNickname"
    uid, token = await MajorLogin(open_id, access_token)
    if not uid or not token:
        return "MajorLogin Issue"
        
    if region == "NULL":
        return {
            "uid": guest_uid,
            "password": password,
            "nickname": nickname,
            "x": uid,
            "region": "N/A"
        }
    else:
        choose_region_request = await choose_region(token, region)
        if choose_region_request:
            return {
                "uid": guest_uid,
                "password": password,
                "nickname": nickname,
                "x": uid,
                "region": region
            }
        else:
            return "Region Lock"

async def store_data(response):
    file_name = "accounts.json"

    if os.path.exists(file_name):
        with open(file_name, "r") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError:
                data = []
    else:
        data = []

    data.append(response)

    with open(file_name, "w") as f:
        json.dump(data, f, indent=4)

async def main():
    print("=== Welcome to the Account CreationTool ===\n")

    regions = [
        'TW', 'EUROPE', 'SAC', 'NA', 'VN', 'ID',
        'ME', 'BD', 'TH', 'US', 'SG', 'IND', 'PK',
        'BR', 'RU'
    ]

    while True:
        try:
            accounts = int(input("How many accounts? "))
            break
        except ValueError:
            print("⚠️ Please enter a valid number.")

    print("\nAvailable regions:", ", ".join(regions))
    while True:
        region = input("Enter region: ").upper()
        if region in regions:
            break
        else:
            print("⚠️ Invalid region. Please choose from the list above.")

    while True:
        try:
            start_sequence = int(input("Enter start sequence (number): "))
            if start_sequence < 0:
                print("⚠️ Start sequence must be positive.")
                continue
            break
        except ValueError:
            print("⚠️ Please enter a valid number.")

    while True:
        use_underscore = input("Do you want an underscore (_) before numbers? (y/n): ").lower()
        if use_underscore in ["y", "n"]:
            break
        else:
            print("⚠️ Please enter 'y' or 'n'.")

    separator = "_" if use_underscore == "y" else ""

    while True:
        nickname = input("Enter your nickname (max 12 letters): ")
        if len(nickname) > 12:
            print("⚠️ Nickname too long! Please enter up to 12 letters.")
            continue

        max_account_name = f"{nickname}{separator}{start_sequence + accounts - 1:03}"
        if len(max_account_name) > 12:
            print(f"⚠️ '{max_account_name}' would exceed 12 characters.")
            print("Please enter a shorter nickname.\n")
            continue
        break

    for i in range(start_sequence, start_sequence + accounts):
        account_id = f"{i:03}"
        account_name = f"{nickname}{separator}{account_id}"

        while True:
            response = await create_account(account_name, region)

            if response == "uid generation issue":
                print("⚠️ Failed to generate uid, please use a VPN.")
                break
                ready = input("Are you ready to retry? (y/n): ").lower()
                if ready == "y":
                    continue
                else:
                    print("Skipping this account.")
                    break

            elif response == "token grant failed":
                print("⚠️ Failed to grant token, please use a VPN.")
                ready = input("Are you ready to retry? (y/n): ").lower()
                if ready == "y":
                    continue
                else:
                    print("Skipping this account.")
                    break

            elif response == "Rate Limit in MajorRegister.":
                print("⚠️ Rate Limit Occurred, Please use VPN.")
                ready = input("Are you ready to retry? (y/n): ").lower()
                if ready == "y":
                    continue
                else:
                    print("Skipping this account.")
                    break

            elif response == "PutNickname":
                new_name = input(f"⚠️ Nickname {account_name} already exists, please put new nickname: ")
                account_name = new_name
                continue

            elif response == "MajorLogin Issue":
                print("⚠️ Something went wrong in MajorLogin.")
                break
                ready = input("Are you ready to retry? (y/n): ").lower()
                if ready == "y":
                    continue
                else:
                    print("Skipping this account.")
                    break

            elif response == "Region Lock":
                print("⚠️ Failed to lock in a region.")
                ready = input("Are you ready to retry? (y/n): ").lower()
                if ready == "y":
                    continue
                else:
                    print("Skipping this account.")
                    break

            else:
                print(f"Account created: {account_name}")
                await store_data(response)
                break


if __name__ == "__main__":
    asyncio.run(main())